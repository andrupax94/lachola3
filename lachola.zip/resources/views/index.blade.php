<!doctype html>
<html lang="en" data-critters-container>
<head>
  <meta charset="utf-8">
  <title>Lachola</title>
  <base href="http://lachola.test/">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/x-icon" href="favicon.ico">
<link rel="stylesheet" href="styles.ef46db3751d8e999.css"></head>
<body>
  <app-root></app-root>
<script src="runtime.749ba95d88c05935.js" type="module"></script><script src="polyfills.dde7447b6f17697d.js" type="module"></script><script src="main.9e48217eef110d98.js" type="module"></script></body>
</html>
