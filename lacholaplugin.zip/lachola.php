<?php

/*
Plugin Name: Subdominio Plugin
Description: Muestra una página web de un subdominio e inicia sesión automáticamente.
Version: 1.0
Author: Tu Nombre
 */
use Firebase\JWT\JWT;

// Hook para ejecutar la función después de iniciar sesión
add_action('wp_login', 'generar_token_despues_de_iniciar_sesion', 10, 2);

function generar_token_despues_de_iniciar_sesion($user_login, $user)
{
    // Configura la clave secreta (puedes cambiarla según tus necesidades)
    $clave_secreta = '.Ana*123';

    // Obtiene el ID del usuario actual
    $emisor = 'http://wpgraphql.test'; // Reemplaza con tu dominio

// Obtiene el ID del usuario actual
    $user_id = get_current_user_id();

// Configura la información del token
    $token_data = array(
        'iss' => $emisor,
        'data' => [
            'user' => [
                'id' => $user_id,
            ],
        ],
        'exp' => strtotime("+1 day"), // Configura la expiración del token
    );

    // Asegúrate de tener la clave secreta en el segundo argumento
    $token = JWT::encode($token_data, $clave_secreta, 'HS256');

    // Puedes hacer lo que necesites con el token aquí
    // Por ejemplo, puedes almacenarlo en algún lugar o enviarlo al cliente

    // Si deseas redirigir al usuario después de iniciar sesión, puedes hacerlo así

}

// Esta función se ejecutará cuando se active el plugin
function mostrar_subdominio_contenido()
{

    $html = file_get_contents(plugin_dir_path(__FILE__) . 'index.html');
    echo $html;
    //    $text='   popupWindow.document.write("'.$html.'");';
    //    echo '<div id="angular-app-container">';
    // echo '<script>';
    // echo 'window.addEventListener("DOMContentLoaded", function() {';
    // echo '  var popupWindow = window.open("", "NombreDeLaVentana", "width=800, height=600");';
    // echo '  if (popupWindow) {';
    // echo $text;
    // echo '    popupWindow.document.close();';
    // echo '  } else {';
    // echo '    console.error("Error al abrir la ventana emergente");';
    // echo '  }';
    // echo '});';
    // echo '</script>';
    // echo '</div>';
}

// Esta acción agrega la función anterior al contenido de la página
add_action('the_content', 'mostrar_subdominio_contenido');

// Esta acción agrega un menú en la barra lateral del panel de administración
add_action('admin_menu', 'subdominio_plugin_menu');

// Esta función crea el menú en la barra lateral
function subdominio_plugin_menu()
{
    add_menu_page(
        'Subdominio Plugin',
        'Subdominio',
        'manage_options',
        'subdominio-plugin',
        'mostrar_subdominio_contenido'
    );
}

//CARGAR IMAGENES
//
function custom_image_url_endpoint()
{
    // Registra el endpoint para obtener la URL de la imagen por ID
    register_rest_route('custom/v1', '/image/(?P<id>\d+)', array(
        'methods' => 'GET',
        'callback' => 'get_image_by_id',
    ));
}

add_action('rest_api_init', 'custom_image_url_endpoint');

function get_image_by_id($data)
{
    $attachment_id = $data['id'];
    $image_url = wp_get_attachment_url($attachment_id);

    if ($image_url) {
        // Obtiene el tipo de contenido de la imagen
        $filetype = wp_check_filetype($image_url, null);

        // Configura las cabeceras para la respuesta
        header("Content-Type: {$filetype['type']}");
        header('Content-Disposition: inline; filename="' . basename($image_url) . '"');

        // Lee y envía la imagen al navegador
        readfile($image_url);
        exit;
    } else {
        // Maneja el caso en el que la imagen no se encuentre
        return new WP_Error('image_not_found', 'Imagen no encontrada', array('status' => 404));
    }
}

//FILTRO MILAGROSO
// This enables the orderby=menu_order for Posts
add_filter('rest_post_collection_params', 'filter_add_rest_orderby_params', 10, 1);
// And this for a custom post type called 'portfolio'
add_filter('rest_evento_collection_params', 'filter_add_rest_orderby_params', 10, 1);
function maximum_api_filter($query_params)
{
    $query_params['per_page']["maximum"] = 1000;
    return $query_params;
}
add_filter('rest_evento_collection_params', 'maximum_api_filter');
/**
 * Add menu_order to the list of permitted orderby values
 */
function filter_add_rest_orderby_params($params)
{
    $custom_fields = array(
        "acm_fields.banner",
        "acm_fields.imagen",
        "acm_fields.nombre",
        "acm_fields.descripcion",
        "acm_fields.tasa",
        "acm_fields.categoria",
        "acm_fields.tipoMetraje",
        "acm_fields.tipoFestival",
        "acm_fields.fechaInicio",
        "acm_fields.fechaLimite",
        "acm_fields.fuente",
        "acm_fields.url",
        "acm_fields.telefono",
        "acm_fields.correoElectronico",
        "acm_fields.web",
        "acm_fields.facebook",
        "acm_fields.ubicacion",
        "acm_fields.instagram",
        "acm_fields.youtube",
        "acm_fields.industrias",
        "acm_fields.twitterX",
        // Agrega tantos campos personalizados como desees permitir
    );

    $params['orderby']['enum'] = array_merge($params['orderby']['enum'], $custom_fields);
    return $params;
}